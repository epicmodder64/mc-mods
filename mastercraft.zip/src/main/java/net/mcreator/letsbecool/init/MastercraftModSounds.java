
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.letsbecool.init;

import net.minecraft.sounds.SoundEvent;

import net.mcreator.letsbecool.MastercraftMod;

public class MastercraftModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MastercraftMod.MODID);
	public static final RegistryObject<SoundEvent> PIANO_CLASSIC = REGISTRY.register("piano_classic", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("mastercraft", "piano_classic")));
}
