
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.letsbecool.init;

import net.mcreator.letsbecool.MastercraftMod;

public class MastercraftModPaintings {
	public static final DeferredRegister<PaintingVariant> REGISTRY = DeferredRegister.create(ForgeRegistries.PAINTING_VARIANTS, MastercraftMod.MODID);
	public static final RegistryObject<PaintingVariant> HELLISHGOOF = REGISTRY.register("hellishgoof", () -> new PaintingVariant(16, 16));
}
