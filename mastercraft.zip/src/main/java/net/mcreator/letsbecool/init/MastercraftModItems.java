
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.letsbecool.init;

import net.mcreator.letsbecool.item.AsongimadeusingtrashItem;
import net.mcreator.letsbecool.MastercraftMod;

public class MastercraftModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MastercraftMod.MODID);
	public static final RegistryObject<Item> ASONGIMADEUSINGTRASH = REGISTRY.register("asongimadeusingtrash", () -> new AsongimadeusingtrashItem());
	public static final RegistryObject<Item> HAPPINESSFLOWER = block(MastercraftModBlocks.HAPPINESSFLOWER);
	public static final RegistryObject<Item> OREOFKEVINMACLEOD = block(MastercraftModBlocks.OREOFKEVINMACLEOD);

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
