
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.letsbecool.init;

import net.mcreator.letsbecool.block.OreofkevinmacleodBlock;
import net.mcreator.letsbecool.block.HappinessflowerBlock;
import net.mcreator.letsbecool.block.EpicdiminsionPortalBlock;
import net.mcreator.letsbecool.MastercraftMod;

public class MastercraftModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MastercraftMod.MODID);
	public static final RegistryObject<Block> HAPPINESSFLOWER = REGISTRY.register("happinessflower", () -> new HappinessflowerBlock());
	public static final RegistryObject<Block> OREOFKEVINMACLEOD = REGISTRY.register("oreofkevinmacleod", () -> new OreofkevinmacleodBlock());
	public static final RegistryObject<Block> EPICDIMINSION_PORTAL = REGISTRY.register("epicdiminsion_portal", () -> new EpicdiminsionPortalBlock());
}
