
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.letsbecool.init;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MastercraftModTabs {
	@SubscribeEvent
	public static void buildTabContentsModded(CreativeModeTabEvent.Register event) {
		event.registerCreativeModeTab(new ResourceLocation("mastercraft", "mastercraft"),
				builder -> builder.title(Component.translatable("item_group.mastercraft.mastercraft")).icon(() -> new ItemStack(MastercraftModBlocks.EPICDIMINSION_PORTAL.get())).displayItems((parameters, tabData) -> {
					tabData.accept(MastercraftModBlocks.HAPPINESSFLOWER.get().asItem());
					tabData.accept(MastercraftModBlocks.OREOFKEVINMACLEOD.get().asItem());
				}).withSearchBar());
	}
}
