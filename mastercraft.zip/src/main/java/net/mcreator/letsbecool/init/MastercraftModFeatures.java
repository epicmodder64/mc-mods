
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.letsbecool.init;

import net.mcreator.letsbecool.world.features.plants.HappinessflowerFeature;
import net.mcreator.letsbecool.MastercraftMod;

@Mod.EventBusSubscriber
public class MastercraftModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, MastercraftMod.MODID);
	public static final RegistryObject<Feature<?>> HAPPINESSFLOWER = REGISTRY.register("happinessflower", HappinessflowerFeature::new);
}
