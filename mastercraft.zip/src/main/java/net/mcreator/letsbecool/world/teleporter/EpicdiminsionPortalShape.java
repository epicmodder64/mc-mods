
package net.mcreator.letsbecool.world.teleporter;

public class EpicdiminsionPortalShape /* failed to load code for net.minecraft.world.level.portal.PortalShape */
